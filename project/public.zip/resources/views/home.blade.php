@extends('adminlte::page')

@section('title', 'AdminPanel')

@section('content_header')
    <h1>Администратор</h1>
@stop

@section('content')
    <p>Вы успешно вошли!</p>
    <h4>Здесь вы можете изменить настройки администратора, а также редактировать данные организаций.</h4>
@stop