<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Учителя</title>
  </head>

  <body>
    <div class="container">
      <div class="teachers">
        <h2 class="block-title my-border-ref">Учителя</h2>
        <h3>Родного мордовского языка:</h3>
        <div class="row">
          <div class="col col-md-6 block-teachers shadow-d">
            <div class="col-12 block-teacher">
              <span class="surname"></span>
              <span class="name"></span>
              <span class="patronymic"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
